import { Instruction } from "../src/models/abstract/Instruction"

export type IdDec = {
    id: Instruction;
    value: Instruction | undefined;
}