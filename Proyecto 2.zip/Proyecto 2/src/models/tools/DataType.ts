export enum DataType {
    INT,
    FLOAT,
    STRING,
    BOOL,
    CHAR
}